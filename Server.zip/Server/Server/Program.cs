﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;

namespace Server
{
    class Program
    {
        static void Main(string[] args)
        {
            Socket Listener = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            
            IPAddress adr = Dns.Resolve("10.202.0.71").AddressList[0];
            IPEndPoint ipEnd = new IPEndPoint(adr, 8086);
            Listener.Bind(ipEnd);
            Listener.Listen(10);
            Console.WriteLine("Ожидание соединения...");
            Socket s = Listener.Accept();
            byte[] bufR = new byte[1024];
            int sum = 0;
            int i = 1;
            while (i <= 3)
            {
                s.Receive(bufR);
                string data = Encoding.ASCII.GetString(bufR);
                Console.WriteLine("{0} -e число: {1}", i,data);
                sum += Convert.ToInt32(data);
                i++;
            }
            byte[] bufS = Encoding.ASCII.GetBytes(sum.ToString());
            s.Send(bufS);
            Console.WriteLine("результат суммы равный {0} - отправлен", sum);
            Console.ReadLine();
            s.Close();
        }
    }
}
