﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Serialization;
using System.Net;
using System.Net.Sockets;
using System.Diagnostics;
using System.IO;


namespace NotFunny
{
    public class Program
    {
        private static FileDetails fileDet;
        private static int localPort = 5002;
        private static UdpClient receivingUdpClient = new UdpClient(localPort);
        private static IPEndPoint RemoteIpEndPoint = null;
        private static FileStream fs;
        private static byte[] receiveByte = new byte[0];
        [Serializable]
        public class FileDetails
        {
            public string FILETYPE = "";
            public long FILESIZE = 0;
        }
        [STAThread]
        static void Main(string[] args)
        {
            GetFileDetails();
            ReceiveFile();
        }
        private static void GetFileDetails()
        {
            try
            {
                Console.WriteLine("---***Ожидание получениия деталей файла!! ****---");
                receiveByte = receivingUdpClient.Receive(ref RemoteIpEndPoint);
                Console.WriteLine("--Детали файла получены!!");
                XmlSerializer fileSerializer = new XmlSerializer(typeof(FileDetails));
                MemoryStream stream1 = new MemoryStream();
                stream1.Write(receiveByte, 0, receiveByte.Length);
                stream1.Position = 0;
                fileDet = (FileDetails)fileSerializer.Deserialize(stream1);
                Console.WriteLine("Получен файл с расширением " + fileDet.FILETYPE + "размером " + fileDet.FILESIZE.ToString() + "байт");
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }
        public static void ReceiveFile()
        {
            try
            {
                Console.WriteLine("---***Ожидание получениия файла!! ****---");
                receiveByte = receivingUdpClient.Receive(ref RemoteIpEndPoint);
                Console.WriteLine("--Сохранение полученного файла!!");
                fs = new FileStream("temp." + fileDet.FILETYPE, FileMode.Create, FileAccess.ReadWrite, FileShare.ReadWrite);
                fs.Write(receiveByte, 0, receiveByte.Length);
                Console.WriteLine("Файл сохранен");
                Console.WriteLine("---Открытие файла с помощью соответствующей программы----");
                Process.Start(fs.Name);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }

            finally
            {
                fs.Close();
            }
        } 
    }
}