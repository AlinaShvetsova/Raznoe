﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;

namespace Klient
{
    class Program
    {
        static void Main(string[] args)
        {
           //сздание сокета
            Socket s1 = new Socket(AddressFamily.InterNetwork,SocketType.Stream, ProtocolType.Tcp);
            IPHostEntry ipHost = Dns.Resolve("10.202.0.33");
            IPAddress ipAdr = ipHost.AddressList[0];
            // создание конечной точки с указанием параметров соединения
            IPEndPoint ipEnd = new IPEndPoint(ipAdr, 8086);
            //соединение с сервером
            s1.Connect(ipEnd);
            Console.WriteLine("Соединение установлено. \n");
            Console.WriteLine("Введите три числа: \n");
            string str = null;
            int i = 1;
            while (i<=3)
            {
                Console.WriteLine("Введите {0} -e число: \n");
                str = Console.ReadLine();
                //буфер для отправляемых данных
                byte[] d = Encoding.ASCII.GetBytes(str);
                //отправка данных
                s1.Send(d);
                Console.WriteLine("{0} -e число отправлено! \n", i);
                i++;
            }
            Console.WriteLine("Все числа отправлены! \n");
            byte[] R = new byte[1024];//буфер для получения данных из сети
            //получение результата
            s1.Receive(R);
            Console.WriteLine("Вычисленный удаленно результат суммы равен {0}",
                Encoding.ASCII.GetString(R));
            Console.ReadLine();
            s1.Close();


        }
    }
}
